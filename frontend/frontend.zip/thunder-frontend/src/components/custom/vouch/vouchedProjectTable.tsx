import ListItem from "./listItem";
import { Button } from "@/components/ui/button";
import abi from "@/abi/vouches.json";
import getContract from "@/scripts/return-contract";

export default function VouchedProjectsTable() {
  const contractAddress = "0xee82ae5f54a0290c01c51de2697c01f02112a981";

  const DoWithdraw = async () => {
    const contract = await getContract(contractAddress, abi);
    const hell = await contract.printHello();
    console.log("hell = \n",hell);
  }

  return (
    <div className="min-w-[30rem] mx-auto">
      <h1 className="text-xl pt-8 font-bold">The address you vouched for:</h1>
      <ul className="pb-10 pt-4 mx-auto divide-gray-200 dark:divide-gray-700">
        <ListItem address="0xefccacde8d300b56a9dd3e015908871dfb43e286" />
        <Button onClick={DoWithdraw}>Clicky</Button>
      </ul>
    </div>
  );
}
