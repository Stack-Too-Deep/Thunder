import { DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "react-day-picker";

export default function ViewExistingLoansSubpart() {
  // TODO: The following is the test data, replace it with abi data
  const data = [
    {
      loanID: "0xefccacde8d300b56a9dd3e015908871dfb43e286",
      creditScore: "250",
      amount1: "100 ETH",
      amount2: "1000 DAI",
      dueDate: "24th Jan, 24",
    },
    {
      loanID: "0xefccacde8d300b56a9dd3e015908871dfb43e286",
      creditScore: "220",
      amount1: "58 ETH",
      amount2: "69 DAI",
      dueDate: "",
    },
  ];
  return (
    <>
      {/* <DialogHeader>
        <DialogTitle className="font-extrabold">Existing loans</DialogTitle>
      </DialogHeader> */}
      <div className="relative overflow-x-auto shadow-md sm:rounded-lg">
        <table className="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
          <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
            <tr>
              <th scope="col" className="px-6 py-3">
                Loan ID
              </th>
              <th scope="col" className="px-6 py-3">
                Credit Score
              </th>
              <th scope="col" className="px-6 py-3">
                Transaction
              </th>
              <th scope="col" className="px-6 py-3">
                Due Date
              </th>
              <th scope="col" className="px-6 py-3">
                <span className="sr-only">Edit</span>
              </th>
            </tr>
          </thead>
          <tbody>
            {data.map((loan) => {
              console.log(loan);
              return (
                <>
                  <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                    <th
                      scope="row"
                      className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"
                    >
                      {loan.loanID}
                    </th>
                    <td className="px-6 py-4">{loan.creditScore}</td>
                    <td className="px-6 py-4">
                      {loan.amount1} 💱 {loan.amount2}
                    </td>
                    <td className="px-6 py-4">{loan.dueDate}</td>
                    <td className="px-6 py-4 text-right">
                      <Button className="">Repay</Button>
                    </td>
                  </tr>
                </>
              );
            })}
          </tbody>
        </table>
      </div>
    </>
  );
}
